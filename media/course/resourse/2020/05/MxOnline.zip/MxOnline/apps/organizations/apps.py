from django.apps import AppConfig


class OrganizationsConfig(AppConfig):
    name = 'apps.organizations'
    verbose_name = '授课机构'
